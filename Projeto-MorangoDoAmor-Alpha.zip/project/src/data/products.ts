import { Product, Review } from '../types';

export const products: Product[] = [
  {
    id: '1',
    name: 'Kit 3 Morangos do Amor',
    description: 'Tamanho Grande',
    image: 'https://images.pexels.com/photos/4686822/pexels-photo-4686822.jpeg?auto=compress&cs=tinysrgb&w=400',
    originalPrice: 18.99,
    promotionalPrice: 14.99,
    category: 'morangos'
  },
  {
    id: '2',
    name: 'Kit 6 Morangos Especiais',
    description: 'Tamanho Médio com Cobertura Premium',
    image: 'https://images.pexels.com/photos/4686823/pexels-photo-4686823.jpeg?auto=compress&cs=tinysrgb&w=400',
    originalPrice: 32.99,
    promotionalPrice: 24.99,
    category: 'morangos',
    isPickupOnly: true
  },
  {
    id: '3',
    name: 'Combo Romântico',
    description: '12 morangos do amor + 4 uvas do amor',
    image: 'https://images.pexels.com/photos/4686824/pexels-photo-4686824.jpeg?auto=compress&cs=tinysrgb&w=400',
    originalPrice: 89.99,
    promotionalPrice: 46.90,
    category: 'morangos',
    isHighlight: true
  },
  {
    id: '4',
    name: 'Bolo Red Velvet Morango',
    description: 'Fatia individual com morangos frescos',
    image: 'https://images.pexels.com/photos/1126359/pexels-photo-1126359.jpeg?auto=compress&cs=tinysrgb&w=400',
    originalPrice: 16.99,
    promotionalPrice: 12.99,
    category: 'bolos'
  },
  {
    id: '5',
    name: 'Pizza Doce de Morango',
    description: 'Massa doce com creme e morangos frescos',
    image: 'https://images.pexels.com/photos/1653877/pexels-photo-1653877.jpeg?auto=compress&cs=tinysrgb&w=400',
    originalPrice: 28.99,
    promotionalPrice: 22.99,
    category: 'pizzas'
  }
];

export const reviews: Review[] = [
  {
    id: '1',
    customerName: 'Cinthia',
    rating: 5.0,
    comment: 'Morangos deliciosos! A cobertura estava perfeita e chegou rapidinho. Super recomendo!',
    date: '2024-01-15'
  },
  {
    id: '2',
    customerName: 'Roberto',
    rating: 4.8,
    comment: 'Primeira vez pedindo e adorei. Os morangos são frescos e a apresentação é linda.',
    date: '2024-01-14'
  },
  {
    id: '3',
    customerName: 'Ana Clara',
    rating: 5.0,
    comment: 'O combo romântico é perfeito para o encontro! Meu namorado amou a surpresa.',
    date: '2024-01-13'
  },
  {
    id: '4',
    customerName: 'Felipe',
    rating: 4.9,
    comment: 'Entrega super rápida e os morangos estavam deliciosos. Vou pedir sempre!',
    date: '2024-01-12'
  }
];