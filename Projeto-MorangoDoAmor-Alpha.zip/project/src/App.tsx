import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Modal } from './components/Modal';
import { ProductCard } from './components/ProductCard';
import { ComboHighlight } from './components/ComboHighlight';
import { Reviews } from './components/Reviews';
import { Footer } from './components/Footer';
import { products, reviews } from './data/products';
import { ModalState } from './types';

function App() {
  const [modals, setModals] = useState<ModalState>({
    cityModal: true,
    confirmationModal: false
  });

  const handleCitySubmit = (city: string) => {
    console.log('Cidade selecionada:', city);
    setModals({ cityModal: false, confirmationModal: true });
  };

  const handleViewMenu = () => {
    setModals({ cityModal: false, confirmationModal: false });
  };

  const closeModals = () => {
    setModals({ cityModal: false, confirmationModal: false });
  };

  const morangoProducts = products.filter(p => p.category === 'morangos');
  const boloProducts = products.filter(p => p.category === 'bolos');
  const pizzaProducts = products.filter(p => p.category === 'pizzas');

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-red-50">
      <Header />
      
      {/* Modals */}
      <Modal 
        isOpen={modals.cityModal}
        onClose={closeModals}
        type="city"
        onCitySubmit={handleCitySubmit}
      />
      
      <Modal 
        isOpen={modals.confirmationModal}
        onClose={closeModals}
        type="confirmation"
        onViewMenu={handleViewMenu}
      />

      {/* Main Content */}
      <main className="pt-24 pb-12">
        <div className="container mx-auto px-4">
          
          {/* Hero Banner */}
          <section className="mb-12">
            <div className="bg-gradient-to-r from-pink-400 via-pink-500 to-red-800 rounded-3xl p-8 text-white text-center shadow-2xl">
              <h2 className="text-4xl font-bold mb-4" style={{ fontFamily: 'Dancing Script, cursive' }}>
                Exclusivo: Morango do Amor
              </h2>
              <div className="bg-white bg-opacity-20 rounded-2xl p-6 max-w-2xl mx-auto">
                <p className="text-xl font-semibold">
                  🚚 Entrega Grátis para Belo Horizonte e região!
                </p>
                <p className="text-lg mt-2">
                  Aproveite nossa promoção com preços irresistíveis
                </p>
              </div>
            </div>
          </section>

          {/* Combo Highlight */}
          <section className="mb-12">
            <ComboHighlight />
          </section>

          {/* Morangos Section */}
          <section className="mb-12">
            <h3 className="text-2xl font-bold text-gray-800 mb-6">Morangos do Amor</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {morangoProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </section>

          {/* Bolos e Doces Section */}
          <section className="mb-12">
            <h3 className="text-2xl font-bold text-gray-800 mb-6">Bolos e Doces</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {boloProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </section>

          {/* Pizzas Doces Section */}
          <section className="mb-12">
            <h3 className="text-2xl font-bold text-gray-800 mb-6">Pizzas Doces</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {pizzaProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </section>

          {/* Reviews Section */}
          <Reviews reviews={reviews} />
        </div>
      </main>

      <Footer />
    </div>
  );
}

export default App;