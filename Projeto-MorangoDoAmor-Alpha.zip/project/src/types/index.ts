export interface Product {
  id: string;
  name: string;
  description: string;
  image: string;
  originalPrice: number;
  promotionalPrice: number;
  category: 'morangos' | 'bolos' | 'pizzas';
  isPickupOnly?: boolean;
  isHighlight?: boolean;
}

export interface Review {
  id: string;
  customerName: string;
  rating: number;
  comment: string;
  date: string;
}

export interface ModalState {
  cityModal: boolean;
  confirmationModal: boolean;
}