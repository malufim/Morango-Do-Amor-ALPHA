import React, { useState, useEffect } from 'react';
import { Clock, TrendingUp } from 'lucide-react';

export const ComboHighlight: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState({
    hours: 2,
    minutes: 34,
    seconds: 18
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        }
        return prev;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="bg-gradient-to-r from-pink-500 to-red-800 rounded-2xl p-6 text-white shadow-2xl transform hover:scale-105 transition-all duration-300">
      <div className="flex items-center mb-4">
        <TrendingUp className="mr-2" size={24} />
        <span className="bg-white bg-opacity-20 px-3 py-1 rounded-full text-sm font-bold">
          COMBO MAIS VENDIDO!
        </span>
      </div>
      
      <h3 className="text-2xl font-bold mb-2">Combo Romântico Premium</h3>
      <p className="text-pink-100 mb-4">
        12 morangos do amor + 4 uvas do amor – Perfeito para a galera com 47% de desconto.
      </p>
      
      {/* Contador Regressivo */}
      <div className="bg-white bg-opacity-20 rounded-xl p-4 mb-4">
        <div className="flex items-center justify-center mb-2">
          <Clock className="mr-2" size={20} />
          <span className="text-sm font-semibold">Promoção termina em:</span>
        </div>
        
        <div className="flex justify-center space-x-4">
          <div className="text-center">
            <div className="bg-white text-pink-600 rounded-lg p-2 min-w-[50px] font-bold text-xl">
              {timeLeft.hours.toString().padStart(2, '0')}
            </div>
            <span className="text-xs">Horas</span>
          </div>
          <div className="text-center">
            <div className="bg-white text-pink-600 rounded-lg p-2 min-w-[50px] font-bold text-xl">
              {timeLeft.minutes.toString().padStart(2, '0')}
            </div>
            <span className="text-xs">Min</span>
          </div>
          <div className="text-center">
            <div className="bg-white text-pink-600 rounded-lg p-2 min-w-[50px] font-bold text-xl animate-pulse">
              {timeLeft.seconds.toString().padStart(2, '0')}
            </div>
            <span className="text-xs">Seg</span>
          </div>
        </div>
      </div>
      
      <p className="text-sm text-pink-100 mb-4 text-center">
        A maioria dos clientes escolhe esse porque é o melhor custo‑benefício!
      </p>
      
      <div className="flex items-center justify-between">
        <div>
          <span className="text-pink-200 line-through text-lg">R$ 89,99</span>
          <span className="text-3xl font-bold ml-2">R$ 46,90</span>
        </div>
        
        <button className="bg-white text-pink-600 px-6 py-3 rounded-xl font-bold hover:bg-pink-50 transition-colors transform hover:scale-105">
          Pedir Agora
        </button>
      </div>
    </div>
  );
};