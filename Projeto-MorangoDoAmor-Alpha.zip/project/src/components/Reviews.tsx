import React from 'react';
import { Star } from 'lucide-react';
import { Review } from '../types';

interface ReviewsProps {
  reviews: Review[];
}

export const Reviews: React.FC<ReviewsProps> = ({ reviews }) => {
  return (
    <section className="py-12">
      <h2 className="text-3xl font-bold text-gray-800 mb-2">Avaliações</h2>
      <p className="text-gray-600 mb-8">
        4,8 (136 avaliações últimos 90 dias • 1.007 no total)
      </p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {reviews.map((review) => (
          <div key={review.id} className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center">
                <h4 className="font-semibold text-gray-800 mr-2">{review.customerName}</h4>
                <div className="flex items-center bg-yellow-100 px-2 py-1 rounded-full">
                  <Star size={14} className="text-yellow-500 fill-current mr-1" />
                  <span className="text-sm font-medium text-yellow-700">{review.rating}</span>
                </div>
              </div>
              <span className="text-xs text-gray-500">
                {new Date(review.date).toLocaleDateString('pt-BR')}
              </span>
            </div>
            
            <p className="text-gray-700 leading-relaxed">{review.comment}</p>
          </div>
        ))}
      </div>
    </section>
  );
};