import React from 'react';
import { MapPin, Star, Clock } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="fixed top-0 left-0 right-0 bg-white shadow-lg z-40 border-b border-pink-100">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center">
            <h1 className="text-3xl font-bold text-pink-600" style={{ fontFamily: 'Dancing Script, cursive' }}>
              Bella Gourmet
            </h1>
          </div>

          {/* Store Info */}
          <div className="hidden lg:flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <span className="bg-pink-100 text-pink-800 px-3 py-1 rounded-full text-sm font-medium">
                Pedido mínimo R$ 19,99
              </span>
              <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium flex items-center">
                <Clock size={14} className="mr-1" />
                30–50 min • Grátis
              </span>
            </div>
            
            <div className="flex items-center space-x-2">
              <span className="bg-gray-100 text-gray-800 px-3 py-1 rounded-full text-sm font-medium flex items-center">
                <MapPin size={14} className="mr-1" />
                Belo Horizonte – MG • 2,6 km
              </span>
              <span className="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm font-medium flex items-center">
                <Star size={14} className="mr-1 fill-current" />
                4,9 (654 avaliações)
              </span>
              <span className="bg-green-500 text-white px-3 py-1 rounded-full text-sm font-bold">
                ABERTO
              </span>
            </div>
          </div>

          {/* Mobile Info */}
          <div className="lg:hidden flex flex-col items-end space-y-1">
            <div className="flex items-center space-x-2">
              <span className="bg-green-500 text-white px-2 py-1 rounded text-xs font-bold">ABERTO</span>
              <span className="text-sm font-medium flex items-center">
                <Star size={12} className="mr-1 text-yellow-500 fill-current" />
                4,9
              </span>
            </div>
            <span className="text-xs text-gray-600">30–50 min • Grátis</span>
          </div>
        </div>
      </div>
    </header>
  );
};