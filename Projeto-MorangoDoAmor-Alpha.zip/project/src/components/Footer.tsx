import React from 'react';
import { Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-50 py-12 mt-12">
      <div className="container mx-auto px-4">
        <div className="text-center mb-8">
          <button className="bg-gradient-to-r from-pink-500 to-red-800 text-white px-8 py-4 rounded-2xl font-semibold hover:from-pink-600 hover:to-red-900 transition-all duration-300 transform hover:scale-105 flex items-center mx-auto">
            <Heart className="mr-2" size={20} />
            Clique para ver doces em promoção
          </button>
        </div>
        
        <div className="border-t border-gray-200 pt-8">
          <div className="flex flex-wrap justify-center items-center space-x-6 text-sm text-gray-600">
            <a href="#" className="hover:text-pink-600 transition-colors">Política de Privacidade</a>
            <a href="#" className="hover:text-pink-600 transition-colors">Termos de Uso</a>
            <a href="#" className="hover:text-pink-600 transition-colors">Contato</a>
            <a href="#" className="hover:text-pink-600 transition-colors">Sobre Nós</a>
          </div>
          
          <div className="text-center mt-6 text-gray-500">
            <p>&copy; 2024 Bella Gourmet. Feito com 🍓 para você.</p>
          </div>
        </div>
      </div>
    </footer>
  );
};