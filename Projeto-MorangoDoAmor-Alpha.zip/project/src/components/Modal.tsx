import React from 'react';
import { X, MapPin } from 'lucide-react';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'city' | 'confirmation';
  onCitySubmit?: (city: string) => void;
  onViewMenu?: () => void;
}

export const Modal: React.FC<ModalProps> = ({ isOpen, onClose, type, onCitySubmit, onViewMenu }) => {
  const [city, setCity] = React.useState('');

  if (!isOpen) return null;

  const handleCitySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (city.trim() && onCitySubmit) {
      onCitySubmit(city);
      setCity('');
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex items-center justify-center z-50 animate-fadeIn">
      <div className="bg-white rounded-2xl p-8 max-w-md w-full mx-4 shadow-2xl transform animate-scaleIn">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors"
        >
          <X size={24} />
        </button>

        {type === 'city' ? (
          <div className="text-center">
            <div className="mb-6">
              <MapPin className="mx-auto text-pink-500 mb-4" size={48} />
              <h2 className="text-2xl font-bold text-gray-800 mb-2">Onde você está?</h2>
              <p className="text-gray-600">Digite sua cidade para encontrarmos a loja mais próxima</p>
            </div>
            
            <form onSubmit={handleCitySubmit} className="space-y-4">
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="Digite sua cidade..."
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-pink-500 focus:outline-none transition-colors"
                autoFocus
              />
              <button
                type="submit"
                disabled={!city.trim()}
                className="w-full bg-pink-500 text-white py-3 rounded-lg font-semibold hover:bg-pink-600 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
              >
                Confirmar Localização
              </button>
            </form>
          </div>
        ) : (
          <div className="text-center">
            <div className="mb-6">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="text-green-600" size={32} />
              </div>
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Encontramos você!</h2>
              <p className="text-gray-600 mb-2">A loja mais próxima fica a <strong className="text-pink-600">2,6 km</strong> de você!</p>
              <p className="text-gray-600 mb-6">Seu pedido chegará entre <strong className="text-green-600">30 a 50 minutos</strong>.</p>
            </div>
            
            <button
              onClick={onViewMenu}
              className="w-full bg-green-500 text-white py-3 rounded-lg font-semibold hover:bg-pink-500 transition-colors duration-300 transform hover:scale-105"
            >
              Olhar cardápio
            </button>
          </div>
        )}
      </div>
    </div>
  );
};